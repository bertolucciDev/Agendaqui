Você é a IA responsável pela etapa QA-D5 do Agendaqui.

CONTEXTO
Projeto: agendaqui-web
Arquitetura observada: SPA React/Vite com dados MOCK.
A QA-D4 resolveu o bloqueio de boot do runner ao estabelecer `vite preview` como referência correta para execução da SPA. As rotas respondem, porém o teste funcional continua bloqueado por timeout de 30s em `page.fill()`.
A existência da tela de novo local foi observada, mas a criação efetiva não foi comprovada.
A criação ADMINISTRATIVA de agendamento também não foi comprovada.
Existe ainda `heading-order/1` na tela de novo local; trate esse achado separadamente, sem confundi-lo com a falha funcional.
Nenhuma alteração de código é permitida nesta etapa.

OBJETIVO
Executar um diagnóstico funcional definitivo, eliminando a dúvida sobre o timeout do Playwright e descobrindo com evidência se:
- o formulário de criação de local é funcional;
- o timeout é causado por seletor, DOM, overlay, loading, rota, hidratação/JS, autenticação, dados MOCK ou outro fator;
- existe um fluxo administrativo real de criação de agendamento;
- quais são os próximos FIXs necessários, se houver.

FASE 1 — BASELINE
Registre:
- branch;
- SHA;
- git status;
- versão do Node;
- package manager;
- comando de build;
- comando de preview;
- URL e porta;
- navegador/versão do Playwright;
- estado inicial do MOCK.

Não altere arquivos do projeto.

FASE 2 — BOOT
Use `vite preview` ou o mecanismo equivalente comprovadamente compatível com SPA.
Valide:
- GET `/`;
- `/login`;
- `/dashboard`;
- `/dashboard/locations`;
- `/dashboard/locations/new`;
- `/appointments`.

Se houver falha, classifique-a antes de continuar.

FASE 3 — DIAGNÓSTICO DO TIMEOUT DE PAGE.FILL
Na rota `/dashboard/locations/new`, antes de tentar preencher:
1. capture screenshot;
2. registre URL final;
3. extraia DOM relevante;
4. liste `input`, `textarea`, `select`, `button`;
5. liste labels e associações label→controle;
6. registre elementos visíveis/ocultos;
7. registre overlays, dialogs, loaders e elementos com `pointer-events`;
8. registre headings;
9. capture accessibility snapshot quando disponível;
10. registre console.error, pageerror e requestfailed;
11. aguarde explicitamente estados de loading/hidratação quando existirem;
12. só então teste múltiplas estratégias de localização:
   - label;
   - role/name;
   - placeholder;
   - `name`;
   - `id`;
   - seletor CSS estável;
   - locator por estrutura sem depender de texto frágil.

IMPORTANTE:
Não conclua “bug no formulário” apenas porque `page.fill()` expirou.
Determine se:
A) o campo não existe;
B) existe mas está invisível;
C) existe mas está coberto;
D) existe e está visível, mas o locator está errado;
E) existe e está visível, mas a página não terminou de hidratar;
F) existe, porém há bloqueio de autenticação/contexto;
G) há erro de runtime;
H) há estado de loading infinito;
I) há problema no MOCK/dados;
J) outra causa — explicar.

Se o campo existir e estiver utilizável, prossiga.

FASE 4 — FLUXO DE CRIAÇÃO DE LOCAL
Somente se o formulário estiver funcional:
1. preencher dados válidos;
2. submeter;
3. capturar request/payload, quando observável;
4. capturar resposta/status, quando aplicável;
5. verificar feedback visual;
6. verificar redirecionamento;
7. verificar presença na listagem;
8. recarregar a página;
9. verificar persistência;
10. verificar comportamento com mais de um business, se o contexto MOCK permitir;
11. limpar o dado de teste sem alterar código.

Se não for possível concluir, informe exatamente em qual passo o fluxo parou.

FASE 5 — DESCOBERTA DO FLUXO ADMINISTRATIVO DE AGENDAMENTOS
Não confunda o booking público com criação administrativa.

Investigue:
- router;
- links/botões “Novo”, “Criar”, “Adicionar”;
- páginas sob `/appointments`;
- páginas sob `/dashboard`;
- componentes de agenda/calendário;
- serviços/API/mock de appointments;
- ações disponíveis na UI.

Se existir fluxo administrativo, mapeie:
business → local → serviço → profissional → data → horário → cliente → submit.

Depois:
- capture payload;
- capture resposta/status;
- capture feedback;
- verifique agenda/listagem;
- recarregue;
- valide persistência;
- teste timezone;
- teste double submit;
- teste multi-business quando possível.

Se NÃO existir fluxo administrativo comprovável, retorne exatamente:
`APT-ADMIN-CREATE-NAO-IMPLEMENTADO`
e apresente a evidência que sustenta a conclusão.

FASE 6 — BOOKING PÚBLICO
Use o booking público apenas como CONTROLE de que a infraestrutura de agendamento público continua funcional.
Não use o booking público para concluir que o admin create existe.

FASE 7 — ACESSIBILIDADE
Registre `heading-order/1` separadamente.
Não o trate como causa do timeout.
Se houver novos achados de axe, liste por rota e regra.

CLASSIFICAÇÃO
Para cada achado use:
- CONFIRMADO
- PROVÁVEL
- HIPÓTESE
- DESCONHECIDO

Use severidade única:
- P0 bloqueador crítico;
- P1 alto impacto funcional;
- P2 impacto moderado;
- P3 baixo impacto/polimento.

CRITÉRIO DE SAÍDA
A D5 deve terminar com:
- causa do timeout classificada;
- evidência objetiva do formulário de local;
- status do create→list→refresh de local;
- status da criação administrativa de agendamento;
- separação entre booking público e admin;
- achados de acessibilidade separados;
- arquivos/componentes envolvidos;
- riscos;
- recomendação do próximo FIX;
- testes que o FIX deverá executar.

NÃO FAÇA
- não editar código;
- não corrigir o timeout;
- não corrigir `heading-order`;
- não criar novas rotas;
- não alterar mocks;
- não alterar banco;
- não mascarar timeout aumentando indiscriminadamente o timeout;
- não declarar “implementado” sem evidência de execução.

RETORNO OBRIGATÓRIO

### QA-D5 — RETORNO

#### 1. STATUS
[FECHADA / PARCIAL / BLOQUEADA]

#### 2. BASELINE
- Branch:
- SHA:
- Git status:
- Node:
- Package manager:
- Build:
- Preview:
- URL:
- Browser:
- MOCK:

#### 3. BOOT
- Resultado:
- Evidências:
- Causa, se houver:

#### 4. TIMEOUT `page.fill()`
- Locator usado:
- Elemento esperado:
- Elemento encontrado:
- Visibilidade:
- Cobertura/overlay:
- Loading:
- Hidratação:
- Runtime:
- Auth/contexto:
- Causa classificada:
- Severidade:

#### 5. LOCAIS
- Rota:
- Formulário encontrado:
- Submit:
- Payload:
- Response/status:
- Feedback:
- Listagem:
- Refresh:
- Persistência:
- Multi-business:
- Cleanup:
- Status final:

#### 6. AGENDAMENTOS ADMIN
- Entry point:
- Rota:
- Formulário:
- Campos:
- Submit:
- Payload:
- Response/status:
- Agenda/listagem:
- Refresh:
- Timezone:
- Double submit:
- Multi-business:
- Status final:

#### 7. BOOKING PÚBLICO
- Rota canônica:
- Resultado:
- Usado somente como controle: SIM/NÃO

#### 8. ACESSIBILIDADE
- `heading-order/1`:
- Outros achados:
- Separação do diagnóstico funcional:

#### 9. EVIDÊNCIAS
Liste screenshots, traces, logs, DOM, accessibility snapshots e arquivos inspecionados.

#### 10. DIAGNÓSTICO
- Problema:
- Causa:
- Impacto:
- Risco:
- Classificação de cada hipótese:

#### 11. DECISÃO
Defina se existe evidência suficiente para liberar um FIX.
Se sim, indique se é:
- FIX-LOC;
- FIX-APT;
- ambos;
- ou outro FIX explicitamente justificado.

#### 12. CONTEXTO FALTANTE
Liste apenas o que realmente impede a decisão.

#### 13. PRÓXIMO PASSO
Descreva a próxima etapa objetiva.

IMPORTANTE:
Não considere a etapa encerrada apenas porque a página abre.
O objetivo é fechar o diagnóstico funcional com evidência.
