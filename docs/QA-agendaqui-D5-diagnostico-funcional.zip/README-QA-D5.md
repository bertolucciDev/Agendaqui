# QA-D5 — Diagnóstico Funcional de Locais e Agendamentos

## Objetivo
Fechar as lacunas deixadas pela QA-D4 antes de qualquer alteração de código.

## Contexto herdado da D4
- O problema de boot do runner foi diagnosticado: `vite preview` deve ser usado para a SPA; não considerar `serve dist` sem fallback como prova de falha da aplicação.
- A rota de criação de local existe e responde, mas o fluxo de criação ainda não foi comprovado.
- O `page.fill()` continua expirando após 30s; isso é sintoma, não causa raiz.
- A criação administrativa de agendamentos ainda não foi comprovada.
- O achado `heading-order/1` da tela de novo local é separado do problema funcional.
- Nenhum FIX deve ser executado nesta etapa.

## Gate
A D5 só pode ser considerada concluída quando houver evidência suficiente para classificar:
1. causa do timeout do preenchimento;
2. existência e comportamento do formulário de criação de local;
3. persistência/feedback do cadastro de local, se o fluxo existir;
4. existência ou ausência comprovada do fluxo administrativo de criação de agendamento;
5. impacto e severidade de cada achado.

## Regra
Investigar primeiro. Não alterar `src/`, rotas, APIs, mocks ou componentes.
