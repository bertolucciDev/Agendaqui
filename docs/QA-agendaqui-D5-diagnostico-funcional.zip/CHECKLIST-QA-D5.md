# QA-D5 — Checklist de Execução

## Antes
- [ ] branch/SHA/git status registrados
- [ ] Node/package manager registrados
- [ ] build executado
- [ ] `vite preview` iniciado
- [ ] `/`, `/login`, `/dashboard`, `/dashboard/locations/new`, `/appointments` validados

## Timeout
- [ ] screenshot antes do fill
- [ ] DOM capturado
- [ ] inputs/labels/buttons listados
- [ ] visibilidade verificada
- [ ] overlay/pointer-events verificados
- [ ] loading/hidratação verificados
- [ ] console/pageerror/requestfailed verificados
- [ ] locator alternativo testado
- [ ] causa classificada

## Locais
- [ ] formulário confirmado
- [ ] submit executado
- [ ] payload/status capturados
- [ ] feedback confirmado
- [ ] listagem confirmada
- [ ] refresh confirmado
- [ ] persistência confirmada
- [ ] cleanup realizado

## Agendamentos
- [ ] router inspecionado
- [ ] entry points inspecionados
- [ ] admin vs público separado
- [ ] admin create confirmado ou `APT-ADMIN-CREATE-NAO-IMPLEMENTADO`
- [ ] payload/status capturados se existir
- [ ] agenda/listagem/refresh validados
- [ ] timezone/double submit/multi-business avaliados

## Encerramento
- [ ] achados classificados
- [ ] severidade P0-P3 definida
- [ ] `heading-order/1` separado
- [ ] sem alterações em src
- [ ] recomendação de FIX baseada em evidência
