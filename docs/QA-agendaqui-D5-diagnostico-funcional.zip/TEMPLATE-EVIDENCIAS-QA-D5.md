# QA-D5 — Template de Evidências

## Execução
- Data/hora:
- Branch:
- SHA:
- Node:
- Package manager:
- Browser:
- URL:

## Evidência E01 — Boot
- Comando:
- Resultado:
- Screenshot:
- Logs:

## Evidência E02 — Tela de novo local
- URL:
- Screenshot:
- Headings:
- Inputs:
- Labels:
- Buttons:
- Overlays:
- Loading:
- Accessibility snapshot:

## Evidência E03 — Timeout
- Locator:
- Mensagem:
- Tempo:
- Estado do elemento:
- Causa:

## Evidência E04 — Criação de local
- Dados de teste:
- Payload:
- Response:
- Feedback:
- Listagem:
- Refresh:
- Persistência:

## Evidência E05 — Admin appointment
- Entry point:
- Rota:
- Campos:
- Payload:
- Response:
- Resultado:

## Evidência E06 — Acessibilidade
- Rota:
- Rule:
- Impact:
- Screenshot/DOM:

## Conclusão
- Confirmados:
- Prováveis:
- Hipóteses:
- Desconhecidos:
- FIX liberado?:
- Justificativa:
